package com.cg.banking.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.Assert;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Address;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.BankingDAOServicesImpl;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.CustomerNotFoundException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;
import com.cg.banking.utilities.BankingUtility;



public class BankingServicesTest {
	private static BankingServices bankingServices;
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		bankingServices=new BankingServicesImpl();
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		bankingServices=null;
	}

	@Before
	public void setUp() throws Exception {
		Customer customer1=new Customer(BankingUtility.CUSTOMER_ID_COUNTER++,"sindhu", "k", "a.com", "er4", new Address(12, "ban","kar"), new Address(122,"mum","mah"));
		Customer customer2=new Customer(BankingUtility.CUSTOMER_ID_COUNTER++,"siri", "k", "a.com", "er4", new Address(12, "ban","kar"), new Address(122,"mum","mah"));
		Account account1= new Account(1111, 1, "savings",BankingUtility.ACCOUNT_STATUS_ACTIVE, 5000,BankingUtility.ACCOUNT_NO_COUNTER++);
		Account account2= new Account(2222, 1, "savings",BankingUtility.ACCOUNT_STATUS_BLOCKED, 5000,BankingUtility.ACCOUNT_NO_COUNTER++);
		Account account3= new Account(3333, 1, "savings",BankingUtility.ACCOUNT_STATUS_BLOCKED, 5000,BankingUtility.ACCOUNT_NO_COUNTER++);
		Account account4= new Account(3333, 1, "savings",BankingUtility.ACCOUNT_STATUS_BLOCKED, 5000,BankingUtility.ACCOUNT_NO_COUNTER++);
		Transaction transaction1=new Transaction(BankingUtility.TRANSACTION_ID_COUNTER++, 6000, "deposit");
		Transaction transaction2=new Transaction(BankingUtility.TRANSACTION_ID_COUNTER++, 6000, "withdrawl");

		BankingDAOServicesImpl.customers.put(customer1.getCustomerId(),customer1);
		BankingDAOServicesImpl.customers.put(customer2.getCustomerId(),customer2);
		BankingDAOServicesImpl.customers.get(customer1.getCustomerId()).getAccounts().put(account1.getAccountNo(),account1);
		BankingDAOServicesImpl.customers.get(customer1.getCustomerId()).getAccounts().put(account2.getAccountNo(),account2);
		BankingDAOServicesImpl.customers.get(customer2.getCustomerId()).getAccounts().put(account3.getAccountNo(),account3);
		BankingDAOServicesImpl.customers.get(customer2.getCustomerId()).getAccounts().put(account4.getAccountNo(),account4);
		BankingDAOServicesImpl.customers.get(customer1.getCustomerId()).getAccounts().get(account1.getAccountNo()).getTransactions().put(transaction1.getTransactionId(),transaction1);
		BankingDAOServicesImpl.customers.get(customer1.getCustomerId()).getAccounts().get(account1.getAccountNo()).getTransactions().put(transaction2.getTransactionId(),transaction2);



	}
	@Test
	public void TestAcceptCustomerDetailsForValidData() throws BankingServicesDownException{
		Assert.assertEquals(113, bankingServices.acceptCustomerDetails("gouri", "k", "a.com", "er4", "ban","kar",12,"mum","mah",122));
	}


	@Test (expected=CustomerNotFoundException.class)
	public void TestOpenAccountForInvalidCustomerId() throws InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, BankingServicesDownException{
		bankingServices.openAccount(999, "savings", 5799);
	}
	@Test(expected=InvalidAccountTypeException.class)
	public void TestOpenAccountForInvalidAccountType() throws InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, BankingServicesDownException{
		bankingServices.openAccount(111, "asaffffffff", 5799);
	}
	@Test(expected=InvalidAmountException.class)
	public void TestOpenAccountForInvalidBalance() throws InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, BankingServicesDownException{
		bankingServices.openAccount(111, "savings", 0);
	}
	@Test
	public void TestOpenAccountForValidData() throws InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, BankingServicesDownException{
		Assert.assertEquals(20000005, bankingServices.openAccount(111, "savings", 5000));
	}


	@Test(expected=CustomerNotFoundException.class)
	public void TestDepositAmountForInvalidCustomer() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException{
		bankingServices.depositAmount(800, 20000001, 50000);
	}
	@Test(expected=AccountNotFoundException.class)
	public void TestDepositAmountForInvalidAccountNo() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException{
		bankingServices.depositAmount(111, 224678, 50000);
	}
	@Test(expected=AccountBlockedException.class)
	public void TestDepositAmountForInvalidAccountStatus() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException{
		bankingServices.depositAmount(112, 20000003, 50000);
	}
	@Test
	public void TestDepositAmountForValiddata() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException{
		Assert.assertEquals(10000, bankingServices.depositAmount(111, 20000001, 5000), 0.02);
	}


	@Test(expected=CustomerNotFoundException.class)
	public void TestWithdrawAmountForInvalidCustomerId() throws InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException{
		bankingServices.withdrawAmount(800, 20000001, 5000, 1111);
	}
	@Test(expected=AccountNotFoundException.class)
	public void TestWithdrawAmountForInvalidAccountNo() throws InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException{
		bankingServices.withdrawAmount(111, 20056701, 5000, 1111);
	}
	@Test(expected=InsufficientAmountException.class)
	public void TestWithdrawAmountForInvalidAmmount() throws InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException{
		bankingServices.withdrawAmount(111, 20000001, 10000, 1111);
	}
	@Test(expected=InvalidPinNumberException.class)
	public void TestWithdrawAmountForInvalidPinNo() throws InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException{
		bankingServices.withdrawAmount(111, 20000001, 5000, 100);
	}
	@Test(expected=AccountBlockedException.class)
	public void TestWithdrawAmountForInvalidAccountStatus() throws InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException{
		bankingServices.withdrawAmount(112, 20000003, 5000,3333);
	}
	@Test
	public void TestWithdrawAmountForValiddata() throws InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException{
		Assert.assertEquals(0, bankingServices.withdrawAmount(111, 20000001, 5000,1111), 0.02);
	}


	@Test
	public void TestGetAllCustomerDetailsForValidData() throws BankingServicesDownException{
		Assert.assertEquals(2,bankingServices.getAllCustomerDetails().size());
	}

	@Test
	public void TestGetCustomerAllAccountDetailsForValidData() throws BankingServicesDownException, CustomerNotFoundException{
		Assert.assertEquals(2, bankingServices.getcustomerAllAccountDetails(111).size());
	}

	@Test
	public void TestGetAccountAllTransactionsForValidData() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException{
		Assert.assertEquals(2, bankingServices.getAccountAllTransaction(111, 20000001).size());
	}

	@After
	public void tearDown() throws Exception {
		BankingDAOServicesImpl.customers.clear();
		BankingUtility.CUSTOMER_ID_COUNTER=111;
		BankingUtility.ACCOUNT_NO_COUNTER=20000001l;
		BankingUtility.TRANSACTION_ID_COUNTER=100;

	}
}